                                   #!/usr/bin/python

import socket
import time
import threading
from threading import *
import struct
import binascii
import select
import sys

exitflag = 0

def timeout_func():
#	print('timeout')
    global exitflag
    exitflag = 1

class WIZEthMsgGen:
    def __init__(self, udpsock):
        self.sock = udpsock
        self.msg = bytearray(512)
        self.size = 0

        self.inputs = [self.sock.sock]
        self.outputs = []
        self.errors = []


    def makecommands(self, cmd_list):
        for cmd in cmd_list:
#			print(cmd[0], cmd[1])	
            self.msg[self.size:] = cmd[0]
            self.size += len(cmd[0])
            if cmd[0] is "MA":
                cmd[1] = cmd[1].replace(":", "")
#				print(cmd[1])
                hex_string = cmd[1].decode('hex')
#				print len(cmd[1])
                self.msg[self.size:] = hex_string
                self.size += 6
            else :
                self.msg[self.size:] = cmd[1]
                self.size += len(cmd[1])
            if not "\r\n" in cmd[1]:
                self.msg[self.size:] = "\r\n"
                self.size += 2

#			print(self.size, self.msg)

    def sendcommands(self):
        self.sock.sendto(self.msg)

    def parseresponse(self):
        readready, writeready, errorready = select.select(self.inputs, self.outputs, self.errors, 1)

        t = Timer(2.0, timeout_func)
        t.start()

        while True:

            if(exitflag) :
                break

            for sock in readready:
                if sock == self.sock.sock :
                    data = self.sock.recvfrom()

                    replylists = data.splitlines()

                    f = open('get_cmd.txt', 'w')
                    for i in range(2, len(replylists)):
                        sys.stdout.write("%s\r\n" % replylists[i])
                        info = "%s\r\n" % replylists[i]
                        f.write(info)
                    f.close()

                    readready, writeready, errorready = select.select(self.inputs, self.outputs, self.errors, 1)
