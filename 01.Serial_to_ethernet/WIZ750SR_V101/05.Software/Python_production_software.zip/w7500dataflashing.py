"""
 mbed CMSIS-DAP debugger
 Copyright (c) 2006-2015 ARM Limited

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
"""

import argparse, os, sys
from time import sleep
from random import randrange
import math

parentdir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, parentdir)

import pyOCD
from pyOCD.board import MbedBoard
from pyOCD.utility.conversion import float32beToU32be
import logging
import re
import struct

validmac_re = "^([0-9a-fA-F]{2}:){5}([0-9a-fA-F]{2})$"

def basic_test(board_id, macaddr):
    sys.stdout.write('test\r\n')

    # with MbedBoard.chooseBoard(board_id=board_id) as board:
    mbeds = MbedBoard.chooseBoardAll(board_id=board_id)

    for board in mbeds:
        board.link.open()
        try:
            # print "1"
            board.init()
            # print "2"
        except Exception as e:
            sys.stdout.write("exception: %r\r\n" % e)
            board.link.close()
            break
        addr = 0
        size = 0
        f = None
        binary_file = "config.bin"
        mac_file = "macaddr.txt"
        # target_type = board.getTargetType()

        # if file is None:
        #     binary_file = os.path.join(parentdir, 'binaries', board.getTestBinary())
        # else:
        #     binary_file = file
        
        print "binary file: %s" % binary_file

        try:
            bin_fd = open(binary_file, 'rb')

            bytebuffer = bytearray(bin_fd.read())
            
            bin_fd.close()

            sys.stdout.write('bytebuffer length: %r\r\n' % len(bytebuffer))

            # for i in range(len(bytebuffer)):
            #     sys.stdout.write('%02X ' % bytebuffer[i])
            #     if ((i + 1) % 16) is 0:
            #         sys.stdout.write('\r\n')

        except IOError:
            print "Couldn't open the file"

        memory_map = board.target.getMemoryMap()
        ram_regions = [region for region in memory_map if region.type == 'ram']
        ram_region = ram_regions[0]
        rom_region = memory_map.getBootMemory()

        addr = ram_region.start + 1
        size = 0x502
        addr_bin = rom_region.start
        # addr_flash = rom_region.start + rom_region.length // 2
        addr_data1 = 0x0003FE00
        addr_data2 = 0x0003FF00

        print "\r\nRAM Addr : " + '0x{0:08X}'.format(addr)
        print "\r\nROM Addr : " + '0x{0:08X}'.format(addr_bin)
        print "\r\nROM Length : " + '0x{0:08X}'.format(rom_region.length)
        # print "\r\nFLASH Addr : " + '0x{0:08X}'.format(addr_flash)

        target = board.target
        link = board.link
        flash = board.flash

        isfileupdate = False
        # macaddr = None
        print "\r\n\r\n------ MAC Address Update"
        if macaddr is None:
            mac_fd = open(mac_file)

            temp_macaddr = mac_fd.read()
            mac_fd.close()
            print "%r" % temp_macaddr
            isfileupdate = True
        else:
            temp_macaddr = macaddr

        tmpmac = temp_macaddr.replace(":", "")
        sys.stdout.write('mac: %r\r\n' % tmpmac)
        int_mac = int(tmpmac, 16)
        nextintmac = int_mac + 1
        sys.stdout.write('int mac: %r\r\n' % int_mac)
        # byte_mac = struct.pack('L', int_mac)
        byte_mac = bytearray.fromhex('{:012X}'.format(int_mac))
        next_byte_mac = bytearray.fromhex('{:012X}'.format(nextintmac))

        for i in range(0,6):
            # sys.stdout.write('mac addr: %r' % byte_mac)
            sys.stdout.write('%02X ' % byte_mac[i])

            

        bytebuffer[0:6] = byte_mac[0:6]
        bytebuffer[279:285] = byte_mac[0:6]    


        print "\r\n\r\n------ TEST PROGRAM/ERASE PAGE ------"
        # Fill 3 pages with 0x55
        # page_size = flash.getPageInfo(addr_data1).size
        page_size = 0x100
        fill = [0x55] * page_size
        flash.init()
        for i in range(0, 2):
            address = addr_data1 + page_size * i
            # Test only supports a location with 3 aligned
            # pages of the same size
            # current_page_size = flash.getPageInfo(addr_data1).size
            current_page_size = 0x100
            assert page_size == current_page_size
            assert address % current_page_size == 0
            flash.erasePage(address)
            flash.programPage(address, bytebuffer[256*i:256*(i+1)])
        # Erase the middle page
        # flash.erasePage(addr_flash + page_size)
        # Verify the 1st and 3rd page were not erased, and that the 2nd page is fully erased
        data = target.readBlockMemoryUnaligned8(addr_data1, page_size * 2)

        # sys.stdout.write('data length: %r\r\n' % len(data))
        # for i in range(len(data)):
        #     sys.stdout.write('%02X ' % data[i])
        #     if ((i + 1) % 16) is 0:
        #         sys.stdout.write('\r\n')
        
        expected = bytebuffer[0:512]
        # sys.stdout.write('expected length: %r\r\n' % len(expected))
        # for i in range(len(data)):
        #     sys.stdout.write('%02X ' % (data[i]))
        #     if ((i + 1) % 16) is 0:
        #         sys.stdout.write('\r\n')

        if bytearray(data) == expected:
            print "TEST PASSED"
            if isfileupdate:
                nextmac = ':'.join('{:02X}'.format(next_byte_mac[i]) for i in range(0, 6))
                # print nextmac
                mac_fd = open(mac_file, 'w+')

                mac_fd.write(nextmac)
                mac_fd.close()


        else:
            print "TEST FAILED"

        # print "\r\n\r\n----- FLASH NEW BINARY -----"
        # flash.flashBinary(binary_file, addr_bin)

        target.reset()

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='A CMSIS-DAP python debugger')
    parser.add_argument('-f', help='binary file', dest="file")
    parser.add_argument('-m', help='mac addr', dest="macaddr")
    parser.add_argument('-d', '--debug', action="store_true", help='Enable debug logging')
    args = parser.parse_args()
    level = logging.DEBUG if args.debug else logging.INFO
    logging.basicConfig(level=level)
    file = args.file
    macaddr = args.macaddr
    if macaddr is not None:
        print macaddr
        prog1 = re.compile(validmac_re)
        if not prog1.match(macaddr):
            print "Invalid MAC address"
        # basic_test(None, file)

    print macaddr
    basic_test(None, macaddr)
