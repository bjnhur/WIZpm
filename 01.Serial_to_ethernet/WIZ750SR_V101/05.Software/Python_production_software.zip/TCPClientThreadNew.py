#!/usr/bin/python
# -*- coding: utf-8 -*-

# Implemented by James YS Kim

import sys

sys.path.append('./TCPClient/')
import time
import socket
import getopt
import threading
# import thread

from TCPClient import TCPClient
from time import gmtime, strftime, localtime

msg = "Hello WIZ750SR\r"
# msg = "Hello WIZ750SR 1234567890 abcdefghijklmn"

class TCPClientThreadNew(threading.Thread):
    def __init__(self, serverip, serverport, trycount, baud_index):
        threading.Thread.__init__(self)
        self.serverip = serverip
        self.serverport = serverport
        # self.f = fd
        self.totaltrycount = 0
        self.successcount = 0
        self.failcount = 0
        self.trycount = trycount
        self.client = None
        self.baud_index = baud_index

    def stop(self):
        if self.client is not None:
            self.client.close()
            self.client = None
        sys.stdout.write('thread for %r ' % self.serverip)
        sys.stdout.write('is shutdowning\r\n')
        # if not self.f.closed:
        if self.totaltrycount > 0:
            logstr = "======================================\r\n"
            logstr = logstr + '[' + self.serverip + '] stopped at ' + strftime("%d %b %Y %H:%M:%S", localtime()) + '\r\n'
            logstr = logstr + 'Total try: ' + str(self.totaltrycount) + '\r\n'
            logstr = logstr + 'Success count: ' + str(self.successcount) + '\r\n'
            logstr = logstr + 'Fail count: ' + str(self.failcount) + '\r\n'
            logstr = logstr + 'Success Rate: ' + "{0:.1f}".format(
                float(self.successcount) / float(self.totaltrycount) * 100) + '%\r\n'
            logstr = logstr + '======================================\r\n'
            sys.stdout.write(logstr)
        else:
            logstr = "======================================\r\n"
            logstr = logstr + '[' + self.serverip + '] stopped at ' + strftime("%d %b %Y %H:%M:%S", localtime()) + '\r\n'
            logstr = logstr + 'Connection Failed\r\n'
            logstr = logstr + '======================================\r\n'
            sys.stdout.write(logstr)
        #     self.f.write(logstr)
        self._Thread__stop()

    def run(self):
        SOCK_CLOSE_STATE = 1
        SOCK_OPENTRY_STATE = 2
        SOCK_OPEN_STATE = 3
        SOCK_CONNECTTRY_STATE = 4
        SOCK_CONNECT_STATE = 5

        idle_state = 1
        datasent_state = 2

        sys.stdout.write('thread for %r ' % self.serverip)
        sys.stdout.write('is starting\r\n')

        # TCPClient instance creation

        try:
            self.client = TCPClient(2, self.serverip, self.serverport)
        except:
            self.stop()

        while True:
            if self.client.state is SOCK_CLOSE_STATE:
                try:
                    cur_state = self.client.state
                    self.client.open()
                    # sys.stdout.write('1 : %r' % self.client.getsockstate())
                    if self.client.state is SOCK_OPEN_STATE:
                        sys.stdout.write('[%r] is OPEN\r\n' % (self.serverip))
                        # sys.stdout.write('[%r] client.working_state is %r\r\n' % (self.serverip, self.client.working_state))
                        time.sleep(1)
                except (KeyboardInterrupt, SystemExit):
                    sys.stdout.write('OPEN: keyboard interrupt occured!!')
                    for i in range(self.trycount):
                        print('trycount: ', i)


            elif self.client.state is SOCK_OPEN_STATE:
                cur_state = self.client.state
                self.client.connect()
                try:
                    # sys.stdout.write('2 : %r' % self.client.getsockstate())
                    if self.client.state is SOCK_CONNECT_STATE:
                        sys.stdout.write('[%r] is CONNECTED\r\n' % (self.serverip))
                        # sys.stdout.write('[%r] client.working_state is %r\r\n' % (self.serverip, self.client.working_state))
                        time.sleep(1)
                except (KeyboardInterrupt, SystemExit):
                    sys.stdout.write('CONNECT: keyboard interrupt occured!!\nExit.')
                    for i in range(self.trycount):
                        self.stop()
#                        threads[i].stop()

            elif self.client.state is SOCK_CONNECT_STATE:
                if self.client.working_state == idle_state:
                    # sys.stdout.write('3 : %r' % self.client.getsockstate())
                    try:
                        if self.totaltrycount >= self.trycount:
                            break

                        self.client.write(msg)
                        logstr = '[' + self.serverip + '] sent ' + msg + '\r\n'
                        sys.stdout.write(logstr)
                        # self.f.write(logstr)
                        self.client.working_state = datasent_state
                        self.totaltrycount += 1
                    except Exception as e:
                        sys.stdout.write('%r\r\n' % e)
                elif self.client.working_state == datasent_state:
                    # sys.stdout.write('4 : %r' % self.client.getsockstate())
                    ### 데이터가 다 들어오기전에 읽어서 잘릴때가 있음 (Serial baudrate가 낮을 때)
                    if self.baud_index == 0:
                        print('=====> Lowest speed baud rate')
                        time.sleep(2.5)
                    # elif (self.baud_index > 0) and (self.baud_index < 6):
                    else:
                        # print('=====> baud rate speed:', self.baud_index)
                        time.sleep(1.7)
                    response = self.client.readline()
                    # print('===> TCP reponse',response)
                    if (response != ""):
                        logstr = '[' + self.serverip + '] received ' + response + '\r\n'
                        sys.stdout.write(logstr)
                        sys.stdout.flush()
                        # self.f.write(logstr)
                        if (msg in response):
                            logstr = '[' + self.serverip + ']' + strftime(" %d %b %Y %H:%M:%S",
                                                                          localtime()) + ': success,'
                            self.successcount += 1
                        # sys.stdout.write(logstr)
                        #							self.f.write(logstr)
                        else:
                            logstr = '[' + self.serverip + ']' + strftime(" %d %b %Y %H:%M:%S",
                                                                          localtime()) + ': fail by broken data,'
                            #							sys.stdout.write(logstr)
                            self.failcount += 1
                        # self.f.write(logstr)

                        logstr = logstr + ' success rate: ' \
                                 + "{0:.2f}".format(float(self.successcount) / float(self.totaltrycount) * 100) + '%, [' \
                                 + str(self.successcount) + '/' + str(self.totaltrycount) + ']\r\n\r\n'
                        sys.stdout.write(logstr)
                        # self.f.write(logstr)
                        # time.sleep(1)
                        self.client.working_state = idle_state

                    response = ""

        self.stop()

if __name__ == '__main__':

    dst_ip = ''
    dst_port = 5000
    dst_num = 0
    retrycount = 10

    # msg = "Hello WIZ750SR\r"

    if len(sys.argv) <= 4:
        sys.stdout.write('Invalid syntax. Refer to below\r\n')
        sys.stdout.write('TCPClientThreadNew.py -s <WIZ107SR ip address> -c <server count>\r\n)')
        sys.exit(0)

    try:
        opts, args = getopt.getopt(sys.argv[1:], "hs:c:r:")
    except getopt.GetoptError:
        sys.stdout.write('Invalid syntax. Refer to below\r\n')
        sys.stdout.write('TCPClientThreadNew.py -s <WIZ107SR ip address>  -c <server count>\r\n)')
        sys.exit(0)

    sys.stdout.write('%r\r\n' % opts)

    threads = []

    try:
        for opt, arg in opts:
            if opt == '-h':
                sys.stdout.write('Valid syntax\r\n')
                sys.stdout.write('TCPClientThreadNew.py -s <WIZ107SR ip address>  -c <server count>\r\n')
                sys.exit(0)
            elif opt in ("-s", "--sip"):
                dst_ip = arg
                sys.stdout.write('%r\r\n' % dst_ip)
            elif opt in ("-c", "--count"):
                dst_num = int(arg)
                sys.stdout.write('%r\r\n' % dst_num)
            elif opt in ("-r", "--retry"):
                retrycount = int(arg)
                sys.stdout.write('%r\r\n' % retrycount)

        lastnumindex = dst_ip.rfind('.')
        lastnum = int(dst_ip[lastnumindex + 1:len(dst_ip)])


    # filename = strftime("%d-%b-%Y", localtime()) + '_log.txt'
    # fd = open(filename, 'w')

        for i in range(dst_num):
            t = TCPClientThreadNew(dst_ip[:lastnumindex + 1] + str(lastnum + i), dst_port, retrycount)
            threads.append(t)

        for i in range(dst_num):
            threads[i].start()

        end_flag = False

        while not end_flag:
            end_flag = not end_flag
            for i in range(len(threads)):
                end_flag &= not threads[i].is_alive()

    except (KeyboardInterrupt, SystemExit):
        sys.stdout.write('--------> Keyboard interrupt 33!!\r\n')
        for i in range(dst_num):
            threads[i].stop()
    # finally:
    #     #		time.sleep(5)
    #     fd.close()

