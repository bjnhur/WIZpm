# TCPClient
TCPClient module for communicating as a TCP Client
